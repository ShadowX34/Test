![Снимок](https://github.com/user-attachments/assets/ac41408c-ce1b-44df-87be-9f0e67fd01f8)
